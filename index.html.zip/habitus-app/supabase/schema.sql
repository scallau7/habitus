-- ============================================================
-- HABITUS v0.1 — Supabase schema
-- The economy's golden rules, enforced at the database level.
-- Run in: Supabase Dashboard > SQL Editor > New query > paste > Run
-- ============================================================

-- ---------- ENUMS ----------
create type venue_type as enum ('EARN', 'BURN', 'EARN_BURN');
create type habit_kind as enum ('verified', 'honor');       -- verified = points, honor = streak only
create type reward_eligibility as enum ('all', 'new_customers_only', 'non_members_only');
create type redemption_status as enum ('pending', 'validated', 'expired', 'cancelled');

-- ---------- PROFILES ----------
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null,
  created_at timestamptz not null default now(),
  points_balance int not null default 0 check (points_balance >= 0),
  current_streak int not null default 0,
  longest_streak int not null default 0,
  last_activity_date date
);

-- ---------- VENUES (partners) ----------
create table venues (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text not null,               -- gym, cafe, restaurant, health, supplements...
  vtype venue_type not null,
  zone text,
  is_cheat boolean not null default false,   -- cheat category: requires 7+ day streak to redeem
  is_featured boolean not null default false, -- Destacado (paid placement)
  qr_secret text not null default encode(gen_random_bytes(16), 'hex'), -- printed QR encodes this
  lat double precision,
  lng double precision,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

-- ---------- HABITS ----------
create table habits (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  name text not null,
  kind habit_kind not null,
  venue_id uuid references venues(id),  -- verified habits link to a venue
  is_private boolean not null default false, -- health habits: shown as "wellness session"
  created_at timestamptz not null default now(),
  archived boolean not null default false
);

-- ---------- CHECK-INS (the only way points are born) ----------
create table checkins (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  habit_id uuid references habits(id),
  venue_id uuid references venues(id),        -- null for honor habits
  kind habit_kind not null,
  points_awarded int not null default 0,       -- 0 for honor; computed for verified
  local_date date not null,                    -- user's local date, for caps & streaks
  created_at timestamptz not null default now()
);

-- Golden rule 1: max 1 verified check-in per venue per day
create unique index one_checkin_per_venue_per_day
  on checkins (user_id, venue_id, local_date)
  where venue_id is not null;

-- Golden rule 2: max 1 honor completion per habit per day
create unique index one_honor_per_habit_per_day
  on checkins (user_id, habit_id, local_date)
  where kind = 'honor';

-- ---------- POINTS LEDGER (immutable audit trail) ----------
create table points_ledger (
  id bigint generated always as identity primary key,
  user_id uuid not null references profiles(id) on delete cascade,
  delta int not null,                          -- +earn / -redeem / -expiry
  reason text not null,                        -- 'checkin' | 'signup_bonus' | 'first_checkin_bonus' | 'redemption' | 'expiry'
  ref_id uuid,                                 -- checkin or redemption id
  expires_at date,                             -- earn rows: 90 days out
  created_at timestamptz not null default now()
);

-- ---------- REWARDS (the menu) ----------
create table rewards (
  id uuid primary key default gen_random_uuid(),
  venue_id uuid not null references venues(id) on delete cascade,
  title text not null,                         -- "20% off en un plato"
  points_cost int not null check (points_cost > 0),
  min_ticket_bs numeric(10,2),                 -- consumo mínimo (null = none)
  eligibility reward_eligibility not null default 'all',
  requires_streak int not null default 0,      -- cheat rewards: 7
  partner_cost_bs numeric(10,2),               -- our estimate, for reporting
  active boolean not null default true
);

-- ---------- REDEMPTIONS ----------
create table redemptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  reward_id uuid not null references rewards(id),
  venue_id uuid not null references venues(id),
  points_spent int not null,
  code text not null default upper(substr(encode(gen_random_bytes(4), 'hex'), 1, 6)),
  status redemption_status not null default 'pending',
  expires_at timestamptz not null default now() + interval '15 minutes',
  validated_at timestamptz,
  validated_by text,                           -- staff identifier (pilot: free text)
  local_month text not null,                   -- 'YYYY-MM' for monthly caps
  created_at timestamptz not null default now()
);

-- ---------- ECONOMY PARAMETERS (mirrors the Excel model) ----------
create table economy_params (
  key text primary key,
  value_int int
);
insert into economy_params (key, value_int) values
  ('points_per_checkin', 20),
  ('weekly_cap', 150),
  ('signup_bonus', 50),
  ('first_checkin_bonus', 30),
  ('expiry_days', 90),
  ('max_redemptions_per_venue_month', 2),
  ('max_redemptions_per_month', 6),
  ('streak_mult_7_pct', 10),
  ('streak_mult_21_pct', 20),
  ('streak_mult_30_pct', 30),
  ('cheat_streak_required', 7);

-- ============================================================
-- CORE FUNCTION: verified check-in
-- Enforces: venue QR secret, daily uniqueness, weekly cap,
-- streak multiplier, bonuses, ledger, streak update. One atomic call.
-- ============================================================
create or replace function do_checkin(p_qr_secret text, p_local_date date)
returns json language plpgsql security definer as $$
declare
  v_user uuid := auth.uid();
  v_venue venues%rowtype;
  v_base int; v_cap int; v_week_earned int;
  v_mult int := 0; v_streak int; v_points int;
  v_bonus int := 0; v_is_first boolean;
  v_checkin_id uuid;
begin
  if v_user is null then raise exception 'not_authenticated'; end if;

  select * into v_venue from venues
    where qr_secret = p_qr_secret and active and vtype in ('EARN','EARN_BURN');
  if not found then raise exception 'invalid_venue_qr'; end if;

  select value_int into v_base from economy_params where key='points_per_checkin';
  select value_int into v_cap  from economy_params where key='weekly_cap';

  -- weekly cap: sum of verified points in the last 7 local days
  select coalesce(sum(points_awarded),0) into v_week_earned
    from checkins
    where user_id = v_user and kind='verified'
      and local_date > p_local_date - 7;

  if v_week_earned >= v_cap then
    v_points := 0;  -- cap reached: check-in still counts for streak, no points
  else
    -- streak multiplier
    select current_streak into v_streak from profiles where id = v_user;
    if v_streak >= 30 then v_mult := 30;
    elsif v_streak >= 21 then v_mult := 20;
    elsif v_streak >= 7 then v_mult := 10;
    end if;
    v_points := least(v_base, v_cap - v_week_earned);
    v_points := v_points + (v_points * v_mult / 100);
  end if;

  -- first-ever verified check-in bonus
  select not exists(select 1 from checkins where user_id=v_user and kind='verified')
    into v_is_first;
  if v_is_first then
    select value_int into v_bonus from economy_params where key='first_checkin_bonus';
  end if;

  insert into checkins (user_id, venue_id, kind, points_awarded, local_date)
    values (v_user, v_venue.id, 'verified', v_points, p_local_date)
    returning id into v_checkin_id;

  if v_points + v_bonus > 0 then
    insert into points_ledger (user_id, delta, reason, ref_id, expires_at)
      values (v_user, v_points + v_bonus,
              case when v_is_first then 'checkin+first_bonus' else 'checkin' end,
              v_checkin_id, p_local_date + 90);
  end if;

  -- streak: any activity today extends it (verified or honor handled in trigger-free way)
  update profiles set
    points_balance = points_balance + v_points + v_bonus,
    current_streak = case
      when last_activity_date = p_local_date then current_streak
      when last_activity_date = p_local_date - 1 then current_streak + 1
      else 1 end,
    longest_streak = greatest(longest_streak, case
      when last_activity_date = p_local_date then current_streak
      when last_activity_date = p_local_date - 1 then current_streak + 1
      else 1 end),
    last_activity_date = p_local_date
  where id = v_user;

  return json_build_object(
    'venue', v_venue.name,
    'points', v_points + v_bonus,
    'first_bonus', v_is_first,
    'capped', v_points = 0
  );
end $$;

-- ============================================================
-- CORE FUNCTION: redeem a reward
-- Enforces: balance, streak gate (cheat), monthly caps, 15-min code.
-- ============================================================
create or replace function do_redeem(p_reward_id uuid, p_local_month text)
returns json language plpgsql security definer as $$
declare
  v_user uuid := auth.uid();
  v_reward rewards%rowtype;
  v_venue venues%rowtype;
  v_balance int; v_streak int;
  v_month_total int; v_month_venue int;
  v_cap_total int; v_cap_venue int;
  v_red redemptions%rowtype;
begin
  if v_user is null then raise exception 'not_authenticated'; end if;

  select * into v_reward from rewards where id = p_reward_id and active;
  if not found then raise exception 'reward_not_found'; end if;
  select * into v_venue from venues where id = v_reward.venue_id;

  select points_balance, current_streak into v_balance, v_streak
    from profiles where id = v_user;

  if v_balance < v_reward.points_cost then raise exception 'insufficient_points'; end if;
  if v_streak < v_reward.requires_streak then raise exception 'streak_required'; end if;
  if v_venue.is_cheat then
    if v_streak < (select value_int from economy_params where key='cheat_streak_required')
    then raise exception 'streak_required'; end if;
  end if;

  select value_int into v_cap_total from economy_params where key='max_redemptions_per_month';
  select value_int into v_cap_venue from economy_params where key='max_redemptions_per_venue_month';

  select count(*) into v_month_total from redemptions
    where user_id=v_user and local_month=p_local_month and status <> 'cancelled';
  if v_month_total >= v_cap_total then raise exception 'monthly_limit_reached'; end if;

  select count(*) into v_month_venue from redemptions
    where user_id=v_user and venue_id=v_reward.venue_id
      and local_month=p_local_month and status <> 'cancelled';
  if v_month_venue >= v_cap_venue then raise exception 'venue_monthly_limit_reached'; end if;

  insert into redemptions (user_id, reward_id, venue_id, points_spent, local_month)
    values (v_user, p_reward_id, v_reward.venue_id, v_reward.points_cost, p_local_month)
    returning * into v_red;

  insert into points_ledger (user_id, delta, reason, ref_id)
    values (v_user, -v_reward.points_cost, 'redemption', v_red.id);

  update profiles set points_balance = points_balance - v_reward.points_cost
    where id = v_user;

  return json_build_object('code', v_red.code, 'expires_at', v_red.expires_at,
                           'reward', v_reward.title, 'venue', v_venue.name);
end $$;

-- ============================================================
-- PARTNER VALIDATION (staff enters user's code on validator page)
-- ============================================================
create or replace function validate_redemption(p_code text, p_venue_qr text, p_staff text)
returns json language plpgsql security definer as $$
declare
  v_venue venues%rowtype; v_red redemptions%rowtype;
begin
  select * into v_venue from venues where qr_secret = p_venue_qr and active;
  if not found then raise exception 'invalid_venue'; end if;

  select * into v_red from redemptions
    where code = upper(p_code) and venue_id = v_venue.id and status = 'pending';
  if not found then raise exception 'code_not_found'; end if;
  if v_red.expires_at < now() then
    update redemptions set status='expired' where id=v_red.id;
    raise exception 'code_expired';
  end if;

  update redemptions set status='validated', validated_at=now(), validated_by=p_staff
    where id = v_red.id;
  return json_build_object('ok', true, 'redemption_id', v_red.id);
end $$;

-- ---------- ROW LEVEL SECURITY ----------
alter table profiles enable row level security;
alter table habits enable row level security;
alter table checkins enable row level security;
alter table points_ledger enable row level security;
alter table redemptions enable row level security;
alter table venues enable row level security;
alter table rewards enable row level security;

create policy "own profile" on profiles for select using (auth.uid() = id);
create policy "own profile update" on profiles for update using (auth.uid() = id);
create policy "own habits" on habits for all using (auth.uid() = user_id);
create policy "own checkins read" on checkins for select using (auth.uid() = user_id);
create policy "own ledger read" on points_ledger for select using (auth.uid() = user_id);
create policy "own redemptions read" on redemptions for select using (auth.uid() = user_id);
create policy "venues public read" on venues for select using (active);
create policy "rewards public read" on rewards for select using (active);
-- All writes to checkins/ledger/redemptions happen ONLY via the security-definer functions above.

-- ---------- SEED: pilot venues (Santiago's real list) ----------
insert into venues (name, category, vtype, zone) values
  ('Sport Motion Gym', 'gym', 'EARN_BURN', null),
  ('Alto Tostado', 'cafe', 'EARN_BURN', null),
  ('L''arome', 'cafe', 'EARN_BURN', null),
  ('Cofi', 'cafe', 'BURN', null),
  ('Caffe del Barrio', 'cafe', 'BURN', null),
  ('Valentina Artieda — Nutrición', 'health', 'EARN', null),
  ('Consulta Psicológica', 'health', 'EARN', null);
