export const SUPABASE_URL = 'https://hxypbjqeafkuftpujmqw.supabase.co';
export const SUPABASE_KEY = 'sb_publishable_cCarPZ09IZ0gECCm8PVzwQ_TZLeJZRn';
