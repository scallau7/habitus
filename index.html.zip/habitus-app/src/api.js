import { createClient } from '@supabase/supabase-js';
import { SUPABASE_URL, SUPABASE_KEY } from './config';

export const sb = createClient(SUPABASE_URL, SUPABASE_KEY);

export const today = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};
export const month = () => today().slice(0, 7);

// ---------- auth ----------
export const signUp = (email, password) => sb.auth.signUp({ email, password });
export const signIn = (email, password) => sb.auth.signInWithPassword({ email, password });
export const signOut = () => sb.auth.signOut();

// ---------- data ----------
export async function loadAll() {
  const [{ data: profile }, { data: venues }, { data: rewards }, { data: habits }, { data: checkins }] =
    await Promise.all([
      sb.from('profiles').select('*').single(),
      sb.from('venues_public').select('*'),
      sb.from('rewards').select('*').eq('active', true),
      sb.from('habits').select('*').eq('archived', false),
      sb.from('checkins').select('*').gte('local_date', dateNDaysAgo(7)),
    ]);
  return { profile, venues: venues || [], rewards: rewards || [], habits: habits || [], checkins: checkins || [] };
}

function dateNDaysAgo(n) {
  const d = new Date(Date.now() - n * 86400000);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

// ---------- actions (server-enforced economy) ----------
export async function checkin(qrSecret) {
  const { data, error } = await sb.rpc('do_checkin', { p_qr_secret: qrSecret, p_local_date: today() });
  if (error) throw new Error(parseErr(error));
  return data;
}

export async function honor(habitId) {
  const { data, error } = await sb.rpc('do_honor', { p_habit_id: habitId, p_local_date: today() });
  if (error) throw new Error(parseErr(error));
  return data;
}

export async function redeem(rewardId) {
  const { data, error } = await sb.rpc('do_redeem', { p_reward_id: rewardId, p_local_month: month() });
  if (error) throw new Error(parseErr(error));
  return data;
}

export async function validate(code, venueQr, staff) {
  const { data, error } = await sb.rpc('validate_redemption', { p_code: code, p_venue_qr: venueQr, p_staff: staff });
  if (error) throw new Error(parseErr(error));
  return data;
}

function parseErr(error) {
  const m = (error.message || '').toLowerCase();
  if (m.includes('already') || m.includes('duplicate') || m.includes('one_checkin')) return 'already_today';
  if (m.includes('invalid_venue')) return 'invalid_venue';
  if (m.includes('insufficient')) return 'insufficient';
  if (m.includes('streak')) return 'streak';
  if (m.includes('venue_monthly')) return 'venue_limit';
  if (m.includes('monthly_limit')) return 'month_limit';
  if (m.includes('code_not_found')) return 'code_not_found';
  if (m.includes('code_expired')) return 'code_expired';
  return error.message || 'error';
}
