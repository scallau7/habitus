// Habitus store — v0.1
// DEMO MODE: full economy rules running locally, persisted to localStorage
// so dogfooding streaks survive. When Supabase keys arrive, SupabaseStore
// replaces this with calls to do_checkin / do_redeem / validate_redemption.

const PARAMS = {
  ptsPerCheckin: 20, weeklyCap: 150,
  signupBonus: 50, firstCheckinBonus: 30,
  maxRedempVenueMonth: 2, maxRedempMonth: 6,
  cheatStreak: 7, codeMinutes: 15,
};

export const VENUES = [
  { id: 'sm', name: 'Sport Motion Gym', cat: 'Gimnasio', vtype: 'EARN_BURN', mono: 'SM', dist: '350 m' },
  { id: 'at', name: 'Alto Tostado', cat: 'Café de especialidad', vtype: 'EARN_BURN', mono: 'AT', dist: '600 m' },
  { id: 'la', name: "L'arome", cat: 'Café de especialidad', vtype: 'EARN_BURN', mono: 'LA', dist: '800 m' },
  { id: 'co', name: 'Cofi', cat: 'Café', vtype: 'BURN', mono: 'CO', dist: '450 m' },
  { id: 'cb', name: 'Caffe del Barrio', cat: 'Café', vtype: 'BURN', mono: 'CB', dist: '1,1 km' },
  { id: 'va', name: 'Valentina Artieda', cat: 'Nutrición', vtype: 'EARN', mono: 'VA', dist: '900 m', priv: true },
  { id: 'ps', name: 'Sesión de bienestar', cat: 'Psicología', vtype: 'EARN', mono: 'SB', dist: '750 m', priv: true },
];

export const REWARDS = [
  { id: 'r1', venueId: 'at', title: '10% off en tu pedido', pts: 100, minBs: 30 },
  { id: 'r2', venueId: 'co', title: 'Upgrade de tamaño gratis', pts: 100 },
  { id: 'r3', venueId: 'la', title: '10% off en tu pedido', pts: 100, minBs: 30 },
  { id: 'r4', venueId: 'sm', title: 'Pase de invitado', pts: 500, elig: 'Solo no-miembros' },
  { id: 'r5', venueId: 'sm', title: '20% off primera mensualidad', pts: 1000, elig: 'Solo clientes nuevos' },
  { id: 'r6', venueId: 'cb', title: 'Topping gratis', pts: 100 },
];

const KEY = 'habitus_v01';
const today = () => new Date().toISOString().slice(0, 10);
const month = () => today().slice(0, 7);
const daysAgo = (d1, d2) => Math.round((new Date(d1) - new Date(d2)) / 86400000);

function blank() {
  return {
    name: 'Santiago', points: PARAMS.signupBonus,
    streak: 0, longest: 0, lastActive: null, hadFirstCheckin: false,
    checkins: [],        // {venueId, date, pts}
    honors: [],          // {habitId, date}
    redemptions: [],     // {rewardId, venueId, pts, code, status, expiresAt, month}
    habits: [
      { id: 'h1', name: 'Gimnasio', kind: 'verified', venueId: 'sm', meta: 'Sport Motion · check-in QR · +20 pts' },
      { id: 'h2', name: 'Sesión de bienestar', kind: 'verified', venueId: 'ps', meta: 'Privado · +20 pts' },
      { id: 'h3', name: 'Leer 20 minutos', kind: 'honor', meta: 'Suma a tu racha · sin puntos' },
      { id: 'h4', name: 'Meditar', kind: 'honor', meta: 'Suma a tu racha · sin puntos' },
    ],
  };
}

export function load() {
  try { const s = JSON.parse(localStorage.getItem(KEY)); if (s) return s; } catch {}
  return blank();
}
function save(s) { try { localStorage.setItem(KEY, JSON.stringify(s)); } catch {} }

function multiplier(streak) {
  if (streak >= 30) return 0.30;
  if (streak >= 21) return 0.20;
  if (streak >= 7) return 0.10;
  return 0;
}

function touchStreak(s) {
  const t = today();
  if (s.lastActive === t) return;
  s.streak = s.lastActive && daysAgo(t, s.lastActive) === 1 ? s.streak + 1 : 1;
  s.longest = Math.max(s.longest, s.streak);
  s.lastActive = t;
}

export function weekEarned(s) {
  const t = new Date();
  return s.checkins
    .filter(c => (t - new Date(c.date)) / 86400000 < 7)
    .reduce((a, c) => a + c.pts, 0);
}

// ---- do_checkin (mirrors the SQL function) ----
export function doCheckin(s, venueId) {
  const t = today();
  const v = VENUES.find(x => x.id === venueId);
  if (!v || v.vtype === 'BURN') return { s, err: 'invalid_venue' };
  if (s.checkins.some(c => c.venueId === venueId && c.date === t))
    return { s, err: 'already_today' };

  const earned = weekEarned(s);
  let pts = 0;
  if (earned < PARAMS.weeklyCap) {
    pts = Math.min(PARAMS.ptsPerCheckin, PARAMS.weeklyCap - earned);
    pts += Math.round(pts * multiplier(s.streak));
  }
  let bonus = 0;
  if (!s.hadFirstCheckin) { bonus = PARAMS.firstCheckinBonus; s.hadFirstCheckin = true; }

  s.checkins.push({ venueId, date: t, pts });
  s.points += pts + bonus;
  touchStreak(s);
  save(s);
  return { s, pts: pts + bonus, first: bonus > 0, capped: pts === 0, venue: v.name, mult: multiplier(s.streak) };
}

// ---- honor completion (streak only, zero points) ----
export function doHonor(s, habitId) {
  const t = today();
  const i = s.honors.findIndex(h => h.habitId === habitId && h.date === t);
  if (i >= 0) { s.honors.splice(i, 1); save(s); return { s, undone: true }; }
  s.honors.push({ habitId, date: t });
  touchStreak(s);
  save(s);
  return { s };
}

// ---- do_redeem (mirrors the SQL function) ----
export function doRedeem(s, rewardId) {
  const r = REWARDS.find(x => x.id === rewardId);
  if (!r) return { s, err: 'not_found' };
  const v = VENUES.find(x => x.id === r.venueId);
  if (s.points < r.pts) return { s, err: 'insufficient' };
  if (v.cheat && s.streak < PARAMS.cheatStreak) return { s, err: 'streak' };

  const m = month();
  const monthAll = s.redemptions.filter(x => x.month === m && x.status !== 'cancelled');
  if (monthAll.length >= PARAMS.maxRedempMonth) return { s, err: 'month_limit' };
  if (monthAll.filter(x => x.venueId === r.venueId).length >= PARAMS.maxRedempVenueMonth)
    return { s, err: 'venue_limit' };

  const code = Math.random().toString(36).slice(2, 5).toUpperCase() + '-' +
               Math.random().toString(36).slice(2, 5).toUpperCase();
  const red = {
    rewardId, venueId: r.venueId, pts: r.pts, code, status: 'pending',
    expiresAt: Date.now() + PARAMS.codeMinutes * 60000, month: m,
  };
  s.redemptions.push(red);
  s.points -= r.pts;
  save(s);
  return { s, code, reward: r, venue: v };
}

// ---- validate_redemption (partner side) ----
export function validateCode(s, code) {
  const red = s.redemptions.find(x => x.code === code.toUpperCase() && x.status === 'pending');
  if (!red) return { s, err: 'not_found' };
  if (Date.now() > red.expiresAt) { red.status = 'expired'; save(s); return { s, err: 'expired' }; }
  red.status = 'validated';
  save(s);
  const r = REWARDS.find(x => x.id === red.rewardId);
  const v = VENUES.find(x => x.id === red.venueId);
  return { s, ok: true, reward: r, venue: v };
}

export function honorDoneToday(s, habitId) {
  return s.honors.some(h => h.habitId === habitId && h.date === today());
}
export function checkedInToday(s, venueId) {
  return s.checkins.some(c => c.venueId === venueId && c.date === today());
}
export function resetDemo() { localStorage.removeItem(KEY); location.reload(); }
export { PARAMS };
