import React, { useState, useEffect, useRef, useCallback } from 'react';
import { sb, signIn, signUp, signOut, loadAll, checkin, honor, redeem, validate, today } from './api';
import Scanner from './Scanner';

const Mark = ({ size = 22, color = '#0A0A0A' }) => (
  <svg width={size} height={size} viewBox="0 0 120 120" fill="none">
    <circle cx="60" cy="60" r="44" stroke={color} strokeWidth="11" strokeLinecap="round"
      strokeDasharray="245.2 276.5" transform="rotate(-70 60 60)" />
    <circle cx="60" cy="16" r="9" fill={color} />
  </svg>
);
const Tick = () => (
  <div className="donetick">
    <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
      <path d="M2.5 6.5 5 9 9.5 3.5" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  </div>
);

function PointsArc({ points, target }) {
  const C = 2 * Math.PI * 100;
  const frac = target > 0 ? Math.min(points / target, 1) : 1;
  return (
    <div className="arcwrap">
      <svg width="216" height="216" viewBox="0 0 216 216" fill="none">
        <circle className="arc-bg" cx="108" cy="108" r="100" strokeWidth="3" fill="none" />
        <circle className="arc-fg" cx="108" cy="108" r="100" strokeWidth="3" fill="none"
          strokeDasharray={C} strokeDashoffset={C * (1 - frac)} />
      </svg>
      <div className="heronum">
        <div className="pts">{points}</div>
        <div className="lbl">Puntos</div>
      </div>
    </div>
  );
}

function Sheet({ onClose, children }) {
  return (
    <>
      <div className="veil" onClick={onClose} />
      <div className="sheet">
        <div className="grab" />
        {children}
        <button className="close" onClick={onClose}>Listo</button>
      </div>
    </>
  );
}

const ERR = {
  already_today: 'Ya hiciste check-in en este local hoy.',
  invalid_venue: 'Código QR no reconocido.',
  insufficient: 'Todavía no tenés suficientes puntos.',
  streak: 'Necesitás una racha activa de 7+ días.',
  venue_limit: 'Máximo 2 redenciones por local al mes.',
  month_limit: 'Alcanzaste el máximo de 6 redenciones este mes.',
  code_not_found: 'Código no encontrado o ya usado.',
  code_expired: 'Código expirado (15 minutos).',
};

// ================= AUTH =================
function Auth() {
  const [mode, setMode] = useState('login');
  const [email, setEmail] = useState('');
  const [pass, setPass] = useState('');
  const [err, setErr] = useState(null);
  const [busy, setBusy] = useState(false);

  const go = async () => {
    setBusy(true); setErr(null);
    const fn = mode === 'login' ? signIn : signUp;
    const { error } = await fn(email.trim(), pass);
    setBusy(false);
    if (error) setErr(error.message);
  };

  return (
    <div className="authwrap">
      <div className="authcard">
        <div className="brandrow" style={{ justifyContent: 'center' }}>
          <Mark size={28} /><span className="bwm" style={{ fontSize: 22 }}>habitus</span>
        </div>
        <p className="hint" style={{ marginBottom: 24 }}>Tu constancia vale.</p>
        <input type="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} autoComplete="email" />
        <input type="password" placeholder="Contraseña (mín. 6)" value={pass} onChange={e => setPass(e.target.value)}
          autoComplete={mode === 'login' ? 'current-password' : 'new-password'} />
        {err && <p className="autherr">{err}</p>}
        <button className="close" disabled={busy || !email || pass.length < 6} onClick={go}>
          {busy ? '...' : mode === 'login' ? 'Entrar' : 'Crear cuenta'}
        </button>
        <button className="authswitch" onClick={() => { setMode(mode === 'login' ? 'signup' : 'login'); setErr(null); }}>
          {mode === 'login' ? '¿Primera vez? Crear cuenta' : 'Ya tengo cuenta'}
        </button>
      </div>
    </div>
  );
}

// ================= TODAY =================
function Today({ data, refresh, celebrate }) {
  const { profile, habits, checkins, rewards, venues } = data;
  const [scanning, setScanning] = useState(false);
  const [sheet, setSheet] = useState(null);
  const t = today();

  const doneVenues = new Set(checkins.filter(c => c.local_date === t && c.venue_id).map(c => c.venue_id));
  const doneHonors = new Set(checkins.filter(c => c.local_date === t && c.kind === 'honor').map(c => c.habit_id));
  const weekPts = checkins.filter(c => c.kind === 'verified').reduce((a, c) => a + c.points_awarded, 0);

  const nextReward = rewards.filter(r => r.points_cost > profile.points_balance)
    .sort((a, b) => a.points_cost - b.points_cost)[0];
  const target = nextReward ? nextReward.points_cost : Math.max(profile.points_balance, 100);
  const dateStr = new Date().toLocaleDateString('es-BO', { weekday: 'long', day: 'numeric', month: 'long' });

  const onScan = useCallback(async (qr) => {
    setScanning(false);
    try {
      const res = await checkin(qr);
      celebrate(`+${res.points}`);
      setSheet({ type: 'checkin', res });
      refresh();
    } catch (e) {
      setSheet({ type: 'err', msg: ERR[e.message] || e.message });
    }
  }, [celebrate, refresh]);

  const tapHonor = async (h) => {
    if (doneHonors.has(h.id)) return;
    try { await honor(h.id); refresh(); } catch {}
  };

  return (
    <div className="screen">
      <div className="brandrow"><Mark /><span className="bwm">habitus</span></div>
      <p className="eyebrow">{dateStr}</p>
      <h1>Hola, {profile.display_name}</h1>

      <div className="hero">
        <PointsArc points={profile.points_balance} target={target} />
        <p className="next">
          {nextReward
            ? <>A <strong>{nextReward.points_cost - profile.points_balance} pts</strong> de: {nextReward.title}</>
            : <>Tenés recompensas disponibles</>}
        </p>
        <div className="chiprow">
          <div className="chip" id="streakchip">
            <svg width="12" height="14" viewBox="0 0 12 14" fill="none"><path d="M6 0C6 0 9.5 3.2 9.5 6.4 11 5.8 11.4 4.6 11.4 4.6 12.4 6.6 12 9.4 10.6 11.2 9.4 12.9 7.8 14 6 14 2.7 14 0 11.5 0 8.4 0 5 3.4 3.6 3.4 0.8 4.6 1.5 5.6 2.8 6 4.2 6 4.2 6 1.8 6 0Z" fill="#fff" /></svg>
            {profile.current_streak} {profile.current_streak === 1 ? 'día' : 'días'}
          </div>
          <div className="chip ghost">{Math.min(weekPts, 150)} / 150 pts esta semana</div>
        </div>
      </div>

      <div className="sect">
        <div className="secthead"><h2>Hábitos de hoy</h2></div>
        <div className="card">
          {habits.map(h => {
            const done = h.kind === 'honor' ? doneHonors.has(h.id) : doneVenues.has(h.venue_id);
            const venue = venues.find(v => v.id === h.venue_id);
            return (
              <button key={h.id} className="hrow" onClick={() => h.kind === 'honor' && tapHonor(h)}>
                <div className="hicon">{h.name[0]}</div>
                <div className="hbody">
                  <div className="hname">{h.name} {h.kind === 'verified' && <span className="tag">Earn</span>}</div>
                  <div className="hmeta">
                    {h.kind === 'verified'
                      ? `${venue ? venue.name : ''} · check-in QR · +20 pts`
                      : 'Suma a tu racha · sin puntos'}
                  </div>
                </div>
                {done ? <Tick /> : <div className="ring-open" />}
              </button>
            );
          })}
        </div>
      </div>

      <button className="cta" onClick={() => setScanning(true)}>
        <span>Escanear QR del local</span>
      </button>
      <p className="hint">Hacé check-in al llegar al local</p>

      {scanning && <Scanner onScan={onScan} onClose={() => setScanning(false)} />}

      {sheet?.type === 'checkin' && (
        <Sheet onClose={() => setSheet(null)}>
          <div className="success">
            <div className="bigtick">
              <svg width="30" height="30" viewBox="0 0 30 30" fill="none"><path d="M7 15.5 13 21.5 23 9.5" stroke="#fff" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" /></svg>
            </div>
            <h3>Check-in en {sheet.res.venue}</h3>
            <p className="gain">
              <strong>+{sheet.res.points} pts</strong>
              {sheet.res.first_bonus && ' · incluye bono de primera vez'}
              {sheet.res.capped && ' · tope semanal alcanzado (suma a tu racha)'}
            </p>
          </div>
        </Sheet>
      )}
      {sheet?.type === 'err' && (
        <Sheet onClose={() => setSheet(null)}>
          <div className="success"><h3>Todavía no</h3><p className="gain">{sheet.msg}</p></div>
        </Sheet>
      )}
    </div>
  );
}

// ================= DISCOVER =================
function Discover({ data }) {
  const { venues } = data;
  return (
    <div className="screen">
      <p className="eyebrow">Santa Cruz de la Sierra</p>
      <h1>Descubrir</h1>
      <div className="sect">
        <div className="secthead"><h2>Partners del piloto</h2></div>
        <div className="card">
          {venues.map(v => (
            <div key={v.id} className="prow">
              <div className={`pmono ${v.vtype === 'BURN' ? 'lite' : ''}`}>
                {v.name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase()}
              </div>
              <div className="hbody">
                <div className="hname">{v.name} {v.vtype !== 'BURN' && <span className="tag">Earn</span>}</div>
                <div className="hmeta">{v.category}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ================= REWARDS =================
function Rewards({ data, refresh }) {
  const { profile, rewards, venues } = data;
  const [sheet, setSheet] = useState(null);

  const go = async (r) => {
    try {
      const res = await redeem(r.id);
      setSheet({ type: 'code', res });
      refresh();
    } catch (e) {
      setSheet({ type: 'err', msg: ERR[e.message] || e.message });
    }
  };

  return (
    <div className="screen">
      <p className="eyebrow">Tu billetera</p>
      <h1>Recompensas</h1>
      <div className="walletline">
        <span className="big">{profile.points_balance}</span><span className="unit">pts</span>
      </div>
      <p className="hint" style={{ textAlign: 'left', marginTop: 4 }}>Los puntos vencen a los 90 días</p>

      <div className="tiergrid">
        {[...rewards].sort((a, b) => a.points_cost - b.points_cost).map(r => {
          const v = venues.find(x => x.id === r.venue_id);
          const locked = profile.points_balance < r.points_cost;
          const elig = r.eligibility === 'non_members_only' ? 'Solo no-miembros'
            : r.eligibility === 'new_customers_only' ? 'Solo clientes nuevos' : null;
          return (
            <button key={r.id} className={`tier ${locked ? 'locked' : ''}`} onClick={() => !locked && go(r)}>
              <div className="tpts"><div className="n">{r.points_cost}</div><div className="u">pts</div></div>
              <div className="tdiv" />
              <div className="hbody">
                <div className="tname">{r.title}</div>
                <div className="twhere">
                  {v ? v.name : ''}
                  {r.min_ticket_bs ? ` · consumo mín. Bs ${Number(r.min_ticket_bs)}` : ''}
                  {elig ? ` · ${elig}` : ''}
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {sheet?.type === 'code' && (
        <Sheet onClose={() => setSheet(null)}>
          <div className="success">
            <h3>{sheet.res.reward}</h3>
            <p className="gain">{sheet.res.venue}</p>
            <div className="codebox">{sheet.res.code}</div>
          </div>
          <p className="note">Mostrá este código al pagar. El personal lo valida en el momento.<br />Válido por 15 minutos.</p>
        </Sheet>
      )}
      {sheet?.type === 'err' && (
        <Sheet onClose={() => setSheet(null)}>
          <div className="success"><h3>Todavía no</h3><p className="gain">{sheet.msg}</p></div>
        </Sheet>
      )}
    </div>
  );
}

// ================= VALIDATOR (partner staff) =================
function Validator() {
  const params = new URLSearchParams(location.search);
  const venueQr = params.get('v') || '';
  const [code, setCode] = useState('');
  const [staff, setStaff] = useState('');
  const [res, setRes] = useState(null);
  const [busy, setBusy] = useState(false);

  const go = async () => {
    setBusy(true); setRes(null);
    try {
      await validate(code, venueQr, staff || 'staff');
      setRes({ ok: true });
    } catch (e) {
      setRes({ err: ERR[e.message] || e.message });
    }
    setBusy(false);
  };

  return (
    <div className="vwrap">
      <div className="brandrow"><Mark /><span className="bwm">habitus</span></div>
      <p className="eyebrow">Validador de partner</p>
      <h1>Validar código</h1>
      {!venueQr && <p className="autherr">Falta el enlace del local (parámetro v). Pedile a Habitus tu enlace de validación.</p>}
      <input value={code} onChange={e => setCode(e.target.value.toUpperCase())} placeholder="CÓDIGO" maxLength={8} />
      <input value={staff} onChange={e => setStaff(e.target.value)} placeholder="Tu nombre (personal)" style={{ letterSpacing: 0, fontSize: 16, textTransform: 'none' }} />
      <button className="close" disabled={busy || code.length < 6 || !venueQr} onClick={go}>
        {busy ? '...' : 'Validar'}
      </button>
      {res?.ok && <div className="vres ok">✓ Código válido — aplicar la recompensa</div>}
      {res?.err && <div className="vres bad">{res.err}</div>}
    </div>
  );
}

// ================= SHELL =================
const TABS = [
  { id: 'today', label: 'Hoy' },
  { id: 'discover', label: 'Descubrir' },
  { id: 'rewards', label: 'Recompensas' },
];

export default function App() {
  const [session, setSession] = useState(undefined); // undefined = loading
  const [data, setData] = useState(null);
  const [tab, setTab] = useState('today');
  const isValidator = new URLSearchParams(location.search).has('validator');

  useEffect(() => {
    sb.auth.getSession().then(({ data: { session } }) => setSession(session));
    const { data: sub } = sb.auth.onAuthStateChange((_e, s) => setSession(s));
    return () => sub.subscription.unsubscribe();
  }, []);

  const refresh = useCallback(async () => {
    try { setData(await loadAll()); } catch {}
  }, []);

  useEffect(() => { if (session) refresh(); }, [session, refresh]);

  const celebrate = (text) => {
    const f = document.createElement('div');
    f.className = 'float'; f.textContent = text;
    f.style.left = '50%'; f.style.bottom = '160px'; f.style.transform = 'translateX(-50%)';
    document.body.appendChild(f);
    setTimeout(() => f.remove(), 1200);
    const chip = document.getElementById('streakchip');
    if (chip) { chip.classList.add('pulse'); setTimeout(() => chip.classList.remove('pulse'), 1500); }
  };

  if (isValidator) return <Validator />;
  if (session === undefined) return <div className="authwrap"><Mark size={40} /></div>;
  if (!session) return <Auth />;
  if (!data) return <div className="authwrap"><Mark size={40} /></div>;

  return (
    <div className="app">
      <div className="demobar">
        <span>Piloto Santa Cruz</span>
        <button onClick={() => signOut()}>salir</button>
      </div>
      {tab === 'today' && <Today data={data} refresh={refresh} celebrate={celebrate} />}
      {tab === 'discover' && <Discover data={data} />}
      {tab === 'rewards' && <Rewards data={data} refresh={refresh} />}
      <nav className="tabs">
        {TABS.map(t => (
          <button key={t.id} className={`tab ${tab === t.id ? 'on' : ''}`} onClick={() => setTab(t.id)}>
            <Mark size={20} color={tab === t.id ? '#0A0A0A' : '#8A8880'} />
            {t.label}
          </button>
        ))}
      </nav>
    </div>
  );
}
