import React, { useEffect, useRef, useState } from 'react';
import jsQR from 'jsqr';

export default function Scanner({ onScan, onClose }) {
  const videoRef = useRef(null);
  const [err, setErr] = useState(null);

  useEffect(() => {
    let stream, raf, stopped = false;
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d', { willReadFrequently: true });

    async function start() {
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment' },
        });
        const v = videoRef.current;
        v.srcObject = stream;
        await v.play();
        tick();
      } catch (e) {
        setErr('No se pudo acceder a la cámara. Revisá los permisos del navegador.');
      }
    }
    function tick() {
      if (stopped) return;
      const v = videoRef.current;
      if (v && v.readyState === v.HAVE_ENOUGH_DATA) {
        canvas.width = v.videoWidth;
        canvas.height = v.videoHeight;
        ctx.drawImage(v, 0, 0);
        const img = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQR(img.data, img.width, img.height, { inversionAttempts: 'dontInvert' });
        if (code && code.data) { stop(); onScan(code.data); return; }
      }
      raf = requestAnimationFrame(tick);
    }
    function stop() {
      stopped = true;
      cancelAnimationFrame(raf);
      if (stream) stream.getTracks().forEach(t => t.stop());
    }
    start();
    return stop;
  }, [onScan]);

  return (
    <div className="scanwrap">
      <video ref={videoRef} playsInline muted className="scanvideo" />
      <div className="scanframe" />
      <p className="scanhint">{err || 'Apuntá al código QR del local'}</p>
      <button className="scanclose" onClick={onClose}>Cancelar</button>
    </div>
  );
}
