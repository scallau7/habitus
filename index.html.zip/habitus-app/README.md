# Habitus — v0.1

The loyalty platform for healthy living. Pilot: Santa Cruz de la Sierra.

## What this repo is

- **supabase/schema.sql** — the entire economy as database rules: check-in caps,
  streak multipliers, 90-day expiry, redemption limits, cheat-meal streak gate,
  15-minute validation codes. The golden rules are *enforced*, not suggested.
  All writes go through three atomic functions: `do_checkin`, `do_redeem`,
  `validate_redemption`. The client can never mint points.
- **src/** — React PWA (user app) + partner validator page. (Built next.)

## Architecture (deliberately boring)

| Layer | Choice | Why |
|---|---|---|
| Frontend | React + Vite, PWA | Installable from browser, no app stores, ships in weeks |
| Backend | Supabase (Postgres + Auth + RPC) | Free tier, RLS security, SQL functions = no server to run |
| Hosting | Vercel | Free, git-push deploys |
| Analytics | PostHog | Free tier |
| Errors | Sentry | Free tier |

## Setup — Santiago's steps (30 min total)

1. **Supabase**: supabase.com → New project (region: South America / São Paulo)
   → SQL Editor → paste `supabase/schema.sql` → Run.
2. Copy from Project Settings → API: `Project URL` and `anon public` key.
3. **Vercel**: vercel.com → sign up with GitHub (create GitHub account if needed).
4. Send Claude the two Supabase values → Claude wires the frontend config.
5. Later: buy domain (~$20/yr) and point it at Vercel.

## Anti-fraud model (v0.1)

- Points are born ONLY inside `do_checkin`, which requires the venue's printed
  QR secret. No client-side path can create points.
- 1 check-in per venue per day = unique index (database-level, not app-level).
- Weekly cap, monthly redemption caps, streak gates: all inside the functions.
- Redemption codes live 15 minutes and are validated by staff against the
  venue's own QR secret — a code from venue A cannot be validated at venue B.

## Design system

Ink #0A0A0A on paper #FAFAF8, Geist, ring+dot brand mark.
One electric signal accent, used ONLY for earned moments (points landing,
streak milestones, cheat unlock). Gaming *experience* (juice, motion,
celebration), never gaming *aesthetics*.
